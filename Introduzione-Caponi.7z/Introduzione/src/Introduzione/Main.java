//Christian Caponi 5°CI 02/10/2024

//Per il completamento dell'esercizio è stato impiegato l'uso di Chat GPT per aiutarmi in parti di codice non ben chiare.

package Introduzione;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
			
		int t;  
        int n; 
        
        //Gestione Input Utente
        Scanner input = new Scanner(System.in);
          
        System.out.println("Inserisci il numero di Thread:");
  		t = input.nextInt();
  		
  		System.out.println("Inserisci il Valore massimo fino a cui contare:");
  		n = input.nextInt();

        
        Buffer b = new Buffer(100); 			//buffer condiviso
        
        
        Produttore produttore = new Produttore(b);				//Avvio thread Produttore
        Consumatore consumatore = new Consumatore(b,n);		//Avvio thread Consumatore

        
        new Thread(produttore).start();			//Thread Produttore
        new Thread(consumatore).start();		//Thread Consumatore
        

    }
		
}

