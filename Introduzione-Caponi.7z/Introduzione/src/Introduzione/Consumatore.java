//Christian Caponi 5°CI 02/10/2024

//Per il completamento dell'esercizio è stato impiegato l'uso di Chat GPT per aiutarmi in parti di codice non ben chiare.

package Introduzione;

public class Consumatore implements Runnable {
	
	private Buffer b;					//Rifferimento al buffer
    private int max;					//Variabile che contiene il massimo di numeri generati

    private int Pari = 0;				//Variabile che contiene i numeri pari
    private int Dispari = 0;			//Variabile che contiene i numeri dispari

    public Consumatore(Buffer buffer, int max){
    	
        this.b = buffer;
        this.max = max;
    }


    public void run(){

            int n = b.rimuovi();			//Qui rimuovo un numero dal buffer

            
            if (n % 2 == 0){				//Qui verifico se il numero e pari
            	
            	Pari++;
                
            }else{
            	
            	Dispari++;
            }

      }
}

