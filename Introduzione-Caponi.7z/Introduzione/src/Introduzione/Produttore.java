//Christian Caponi 5°CI 02/10/2024

//Per il completamento dell'esercizio è stato impiegato l'uso di Chat GPT per aiutarmi in parti di codice non ben chiare.

package Introduzione;

import java.util.Random;

public class Produttore implements Runnable {

	private Buffer b;			//Rifferimento al buffer
    private Random r;			//Servirà per generare i numeri casuali

    public Produttore(Buffer buffer){
    	
        this.b = buffer;
        this.r = new Random();
        
    }


    public void run(){

            
            int n = r.nextInt(1023)+1;				//Genera un numero casuale tra 0 e 1023
            b.Inserisci(n);

            
            int attessa = r.nextInt(901) + 100;		//Attende tra 100 e 1000 ms
            
            try{
            	
                Thread.sleep(attessa);				//Metto in pausa il thread per il tempo casualmente generato
                
            }catch(InterruptedException e) {
                 
            	System.out.println("Errore");
            	
           }
       }
   }
	
