//Christian Caponi 5°CI 02/10/2024

//Per il completamento dell'esercizio è stato impiegato l'uso di Chat GPT per aiutarmi in parti di codice non ben chiare.

package Introduzione;

public class Buffer {
	
	private int[] b;					//Array per memorizzare i numeri
    private int Inserisci;				//Variabile per inserire i numeri nel buffer
    private int Rimuovi;				//Variabile per rimuovere i numeri dal buffer
    private int conta; 					//Numero di elementi attualmente nel buffer

    public Buffer(int d){
    	
        b = new int[d];
        Inserisci = 0;
        Rimuovi = 0;
        conta = 0;
    }

    
    //Metodo per aggiungere un numero nel buffer
    public void Inserisci(int n){

        b[Inserisci] = n;				
        Inserisci = (Inserisci + 1) % b.length;			//Aggiorno l'indice di inserimento
        conta++;
    }

    
    //Metodo per rimuovere un numero dal buffer
    public int rimuovi(){
        
        int n = b[Rimuovi];
        
        Rimuovi = (Rimuovi + 1) % b.length;				//Aggiorna l'indice di Rimozione
        
        conta--;
        
        return n;
    }

}
